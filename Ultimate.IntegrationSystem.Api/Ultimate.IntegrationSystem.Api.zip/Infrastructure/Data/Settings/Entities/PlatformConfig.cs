﻿namespace Ultimate.IntegrationSystem.Api.Infrastructure.Data.Settings.Entities
{
    public class PlatformConfig
    {
    }
}
