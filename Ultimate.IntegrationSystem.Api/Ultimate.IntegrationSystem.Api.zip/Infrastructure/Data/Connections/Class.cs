﻿namespace Ultimate.IntegrationSystem.Api.Infrastructure.Data.Connections
{
    public class Class
    {
    }
}
