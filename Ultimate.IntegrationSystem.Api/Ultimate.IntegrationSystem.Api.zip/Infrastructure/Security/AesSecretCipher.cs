﻿namespace Ultimate.IntegrationSystem.Api.Infrastructure.Security
{
    public class AesSecretCipher
    {
    }
}
