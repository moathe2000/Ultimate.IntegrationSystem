﻿namespace Ultimate.IntegrationSystem.Api.Infrastructure.Policies
{
    public class PollyRegistry
    {
    }
}
