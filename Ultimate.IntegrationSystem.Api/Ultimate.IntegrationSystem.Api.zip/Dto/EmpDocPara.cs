﻿namespace Ultimate.IntegrationSystem.Api.Dto
{
    public class EmpDocPara
    {
        public int? P_EMP_NO { get; set; }
        public int? P_CODE_NO { get; set; }
        public int? P_DCMNT_TYP_NO { get; set; }
        public int? P_DOC_OWNR_TYP { get; set; }
    }
}
