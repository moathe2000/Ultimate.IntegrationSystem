﻿namespace Ultimate.IntegrationSystem.Api.Dto
{
    public class EmployeeRecord
    {
    }
}
