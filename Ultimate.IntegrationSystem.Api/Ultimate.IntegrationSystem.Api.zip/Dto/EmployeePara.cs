﻿namespace Ultimate.IntegrationSystem.Api.Dto
{
    public class EmployeePara
    {
        public int? P_EMP_NO { get; set; }
        public int? P_EMP_NO_FROM { get; set; }
        public int? P_EMP_NO_TO { get; set; }
        public int? P_LNG_NO { get; set; } = 1;
    }
}
