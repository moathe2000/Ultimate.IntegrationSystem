﻿namespace Ultimate.IntegrationSystem.Api.Common.Errors
{
    public class BusinessException
    {
    }
}
