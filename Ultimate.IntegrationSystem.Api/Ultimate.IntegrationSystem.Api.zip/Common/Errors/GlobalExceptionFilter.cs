﻿namespace Ultimate.IntegrationSystem.Api.Common.Errors
{
    public class GlobalExceptionFilter
    {
    }
}
